# rBNB

空气项目

```npm i pm2 -g```
```npm run gen-wallet```
```npm run start```
