const config = {
  difficulty: '0x99999',
  tick: 'rBNB',
  walletTablePath: 'wallets.csv',
  rpcUrl: 'https://binance.nodereal.io',
}

module.exports = config
